package com.example.foodapps.viewmodel

import androidx.lifecycle.ViewModel
import com.example.foodapps.data.Food
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class PurchaseHistoryItem(
    val food: Food,
    val purchaseTime: Long = System.currentTimeMillis(),
    val rating: Int? = null,
    val review: String? = null
)

class CartViewModel : ViewModel() {

    private val _cartItems = MutableStateFlow<List<Food>>(emptyList())
    val cartItems: StateFlow<List<Food>> = _cartItems

    private val _purchaseHistory = MutableStateFlow<List<PurchaseHistoryItem>>(emptyList())
    val purchaseHistory: StateFlow<List<PurchaseHistoryItem>> = _purchaseHistory

    fun addToCart(food: Food) {
        _cartItems.value = _cartItems.value + food
    }

    fun removeFromCart(food: Food) {
        _cartItems.value = _cartItems.value - food
    }

    fun clearCart() {
        _cartItems.value = emptyList()
    }

    fun buyNow(food: Food): Boolean {
        _purchaseHistory.value = _purchaseHistory.value + PurchaseHistoryItem(food = food)
        return true
    }

    fun buyItems(): Boolean {
        return if (_cartItems.value.isNotEmpty()) {
            val newHistory = _cartItems.value.map { PurchaseHistoryItem(it) }
            _purchaseHistory.value = _purchaseHistory.value + newHistory
            _cartItems.value = emptyList()
            true
        } else {
            false
        }
    }

    fun checkout(): Boolean = buyItems()

    fun updateReview(index: Int, rating: Int, review: String) {
        val currentList = _purchaseHistory.value.toMutableList()
        if (index in currentList.indices) {
            val item = currentList[index]
            currentList[index] = item.copy(rating = rating, review = review)
            _purchaseHistory.value = currentList
        }
    }

    // Tambahan: Ambil semua review berdasarkan ID makanan
    fun getReviewsForFood(foodId: Int): List<PurchaseHistoryItem> {
        return _purchaseHistory.value.filter { it.food.id == foodId && it.rating != null && it.review != null }
    }

    // Tambahan: Hitung rata-rata rating untuk makanan tertentu
    fun getAverageRating(foodId: Int): Double {
        val reviews = _purchaseHistory.value.filter { it.food.id == foodId && it.rating != null }
        return if (reviews.isNotEmpty()) {
            reviews.map { it.rating!! }.average()
        } else {
            0.0
        }
    }
}
