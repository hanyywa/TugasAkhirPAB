package com.example.foodapps.ui.screen

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.foodapps.data.sampleFoods
import com.example.foodapps.viewmodel.CartViewModel
import com.example.foodapps.viewmodel.FavoriteViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FoodDetailScreen(
    foodId: Int,
    navController: NavController,
    cartViewModel: CartViewModel,
    favoriteViewModel: FavoriteViewModel
) {
    val food = sampleFoods.find { it.id == foodId }

    if (food == null) {
        Text("Makanan tidak ditemukan.")
        return
    }

    val reviews = cartViewModel.getReviewsForFood(food.id)
    val avgRating = cartViewModel.getAverageRating(food.id)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(food.nama) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
        ) {
            Image(
                painter = painterResource(id = food.imageRes),
                contentDescription = food.nama,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))
            Text(text = food.nama, style = MaterialTheme.typography.headlineSmall)
            Text(text = "Rp${food.harga}", style = MaterialTheme.typography.bodyLarge)
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = food.deskripsi)
            Spacer(modifier = Modifier.height(16.dp))

            // Tampilkan rata-rata rating dan jumlah review
            if (reviews.isNotEmpty()) {
                Text(text = "Rating: ${"%.1f".format(avgRating)} ⭐ (${reviews.size} ulasan)", style = MaterialTheme.typography.bodyMedium)
                Spacer(modifier = Modifier.height(8.dp))
                Text("Ulasan:", style = MaterialTheme.typography.titleMedium)
                reviews.forEach { item ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Text("⭐ ${item.rating}")
                            Text("\"${item.review}\"", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            } else {
                Text("Belum ada ulasan untuk makanan ini.")
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(onClick = {
                cartViewModel.addToCart(food)
                navController.navigate("cart")
            }) {
                Text("Beli Sekarang")
            }
        }
    }
}
