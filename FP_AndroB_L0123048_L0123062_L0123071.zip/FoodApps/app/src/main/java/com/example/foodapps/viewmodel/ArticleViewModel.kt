package com.example.foodapps.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.foodapps.data.Article
import com.example.foodapps.data.ArticleRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class ArticleViewModel(
    private val repository: ArticleRepository = ArticleRepository()
) : ViewModel() {

    private val _articles = MutableStateFlow<List<Article>>(emptyList())
    val articles: StateFlow<List<Article>> = _articles

    private val _addedArticles = MutableStateFlow<Set<Int>>(emptySet())
    val addedArticles: StateFlow<Set<Int>> = _addedArticles

    init {
        loadArticles()
    }

    private fun loadArticles() {
        viewModelScope.launch {
            val data = repository.getArticles()
            _articles.value = data
        }
    }

    fun addArticle(articleId: Int) {
        _addedArticles.value = _addedArticles.value + articleId
    }
}