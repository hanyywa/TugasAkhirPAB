package com.example.foodapps.data

import androidx.annotation.DrawableRes
import com.example.foodapps.R

data class Food(
    val id: Int,
    val nama: String,
    val deskripsi: String,
    val harga: Double,
    @DrawableRes val imageRes: Int
)

val sampleFoods = listOf(
    Food(
        id = 1,
        nama = "Nasi Goreng",
        harga = 15000.0,
        deskripsi = "Nasi digoreng dengan toping telor ceplok.",
        imageRes = R.drawable.product1
    ),
    Food(
        id = 2,
        nama = "Ayam Kentucky",
        harga = 20000.0,
        deskripsi = "Ayam dibaluri dengan tepung dan digoreng hingga golden brown.",
        imageRes = R.drawable.product2
    ),
    Food(
        id = 3,
        nama = "Nasi Padang",
        harga = 15000.0,
        deskripsi = "Nasi Padang dengan rasa authentic.",
        imageRes = R.drawable.product3
    ),
    Food(
        id = 4,
        nama = "Kwetiau",
        harga = 16000.0,
        deskripsi = "Kwetiau kenyal pedas manis.",
        imageRes = R.drawable.product4
    ),
    Food(
        id = 5,
        nama = "Ayam Bakar",
        harga = 20000.0,
        deskripsi = "Ayam bakar manis.",
        imageRes = R.drawable.product5
    ),
    Food(
        id = 6,
        nama = "Ayam Geprek",
        harga = 13000.0,
        deskripsi = "Ayam geprek sambal pedas.",
        imageRes = R.drawable.product6
    ),
    Food(
        id = 7,
        nama = "Nasi Kuning",
        harga = 17000.0,
        deskripsi = "Nasi kuning dengan printilannya.",
        imageRes = R.drawable.product7
    ),
    Food(
        id = 8,
        nama = "Nasi Uduk",
        harga = 15000.0,
        deskripsi = "Nasi uduk khas betawi asli.",
        imageRes = R.drawable.product8
    ),
    Food(
        id = 9,
        nama = "Nasi Bakar",
        harga = 20000.0,
        deskripsi = "Nasi bakar bumbu bali",
        imageRes = R.drawable.product9
    ),
    Food(
        id = 10,
        nama = "Magelangan",
        harga = 20000.0,
        deskripsi = "Nasi goreng dicampur dengan bakmi jawa.",
        imageRes = R.drawable.product10
    )
)
