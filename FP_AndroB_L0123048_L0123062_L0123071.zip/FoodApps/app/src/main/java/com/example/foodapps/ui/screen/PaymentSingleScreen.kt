package com.example.foodapps.ui.screen

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.foodapps.data.Food
import com.example.foodapps.viewmodel.CartViewModel
import java.text.NumberFormat
import java.util.*
import androidx.compose.ui.Alignment


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PaymentSingleScreen(
    food: Food,
    navController: NavController,
    cartViewModel: CartViewModel
) {
    val context = LocalContext.current
    val formattedPrice = NumberFormat.getNumberInstance(Locale("id", "ID")).format(food.harga)
    var selectedMethod by remember { mutableStateOf("") }

    val paymentMethods = listOf("Transfer Bank", "QRIS", "E-Wallet", "COD")

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Pembayaran") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Kembali")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text("Makanan: ${food.nama}", style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(8.dp))
                Text("Harga: Rp$formattedPrice", style = MaterialTheme.typography.bodyMedium)
                Spacer(modifier = Modifier.height(16.dp))

                Text("Pilih Metode Pembayaran:", style = MaterialTheme.typography.titleSmall)
                Spacer(modifier = Modifier.height(8.dp))

                paymentMethods.forEach { method ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = selectedMethod == method,
                            onClick = { selectedMethod = method }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = method)
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                if (selectedMethod.isNotEmpty()) {
                    Text(
                        text = "Metode dipilih: $selectedMethod",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            Button(
                onClick = {
                    if (selectedMethod.isEmpty()) {
                        Toast.makeText(context, "Silakan pilih metode pembayaran.", Toast.LENGTH_SHORT).show()
                        return@Button
                    }

                    val success = cartViewModel.buyNow(food)
                    if (success) {
                        Toast.makeText(context, "Pembayaran berhasil!", Toast.LENGTH_SHORT).show()
                        navController.navigate("history") {
                            popUpTo("payment_single/${food.id}") { inclusive = true }
                        }
                    } else {
                        Toast.makeText(context, "Gagal membayar. Coba lagi.", Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 24.dp)
            ) {
                Text("Bayar Sekarang")
            }

        }
    }
}
