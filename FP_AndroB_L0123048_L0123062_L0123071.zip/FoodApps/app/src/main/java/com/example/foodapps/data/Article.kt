package com.example.foodapps.data

data class Article(
    val id: Int,
    val title: String,
    val content: String
)
