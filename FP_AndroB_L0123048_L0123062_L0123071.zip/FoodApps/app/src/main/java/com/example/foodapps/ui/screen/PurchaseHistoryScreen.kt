package com.example.foodapps.ui.screen

import android.text.format.DateFormat
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.foodapps.viewmodel.CartViewModel
import com.example.foodapps.viewmodel.PurchaseHistoryItem

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PurchaseHistoryScreen(
    navController: NavController,
    cartViewModel: CartViewModel
) {
    val purchaseHistory by cartViewModel.purchaseHistory.collectAsState()
    var selectedIndex by remember { mutableStateOf(-1) }
    var showDialog by remember { mutableStateOf(false) }
    var rating by remember { mutableStateOf(0) }
    var review by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Riwayat Pembelian") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Kembali")
                    }
                }
            )
        }
    ) { padding ->
        if (purchaseHistory.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Text("Belum ada pembelian.")
            }
        } else {
            LazyColumn(
                contentPadding = padding,
                modifier = Modifier.padding(16.dp)
            ) {
                itemsIndexed(purchaseHistory) { index, item ->
                    val formattedDate = remember(item.purchaseTime) {
                        DateFormat.format("dd MMM yyyy HH:mm", item.purchaseTime).toString()
                    }

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        elevation = CardDefaults.cardElevation(4.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(text = item.food.nama, style = MaterialTheme.typography.titleMedium)
                            Text(text = "Rp${item.food.harga}", style = MaterialTheme.typography.bodyMedium)
                            Text(text = item.food.deskripsi, style = MaterialTheme.typography.bodySmall)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(text = "Dibeli pada: $formattedDate", style = MaterialTheme.typography.bodySmall)

                            if (item.rating != null && item.review != null) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("Rating: ${item.rating} ⭐")
                                Text("Ulasan: ${item.review}")
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = {
                                    selectedIndex = index
                                    rating = item.rating ?: 0
                                    review = item.review ?: ""
                                    showDialog = true
                                }
                            ) {
                                Text(if (item.rating != null) "Edit Ulasan" else "Beri Ulasan")
                            }
                        }
                    }
                }
            }
        }

        if (showDialog) {
            AlertDialog(
                onDismissRequest = { showDialog = false },
                confirmButton = {
                    TextButton(
                        onClick = {
                            cartViewModel.updateReview(selectedIndex, rating, review)
                            showDialog = false
                        }
                    ) {
                        Text("Simpan")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showDialog = false }) {
                        Text("Batal")
                    }
                },
                title = { Text("Ulasan Produk") },
                text = {
                    Column {
                        Text("Rating:")
                        Row {
                            for (i in 1..5) {
                                IconButton(onClick = { rating = i }) {
                                    Icon(
                                        imageVector = if (i <= rating) Icons.Filled.Star else Icons.Outlined.StarBorder,
                                        contentDescription = "$i bintang"
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Review:")
                        OutlinedTextField(
                            value = review,
                            onValueChange = { review = it },
                            maxLines = 4
                        )
                    }
                }
            )
        }
    }
}