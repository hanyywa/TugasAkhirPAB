package com.example.foodapps.viewmodel

import androidx.lifecycle.ViewModel
import com.example.foodapps.data.Food
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class FavoriteViewModel : ViewModel() {
    private val _favoriteItems = MutableStateFlow<List<Food>>(emptyList())
    val favoriteItems: StateFlow<List<Food>> = _favoriteItems

    fun addToFavorites(food: Food) {
        if (!_favoriteItems.value.contains(food)) {
            _favoriteItems.value = _favoriteItems.value + food
        }
    }

    fun removeFromFavorites(food: Food) {
        _favoriteItems.value = _favoriteItems.value - food
    }
}
