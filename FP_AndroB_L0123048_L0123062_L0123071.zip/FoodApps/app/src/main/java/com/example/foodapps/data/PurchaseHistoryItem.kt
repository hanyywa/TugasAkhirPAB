package com.example.foodapps.data

data class PurchaseHistoryItem(
    val food: Food,
    val purchaseTime: Long, // waktu dalam millis
    val rating: Int? = null,
    val review: String? = null
)
