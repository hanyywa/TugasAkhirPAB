package com.example.foodapps.ui.theme

import androidx.compose.ui.graphics.Color

val PastelBrown = Color(0xFF8D6E63)
val LightBrown = Color(0xFFF3E8DC)
val CardBackground = Color(0xFFFFF9F4)
val PriceColor = PastelBrown
val TextDark = Color(0xFF5D4037)
val TextGray = Color(0xFFA1887F)
