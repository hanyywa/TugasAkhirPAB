package com.example.foodapps.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.constraintlayout.compose.ChainStyle
import androidx.constraintlayout.compose.ConstraintLayout
import com.example.foodapps.data.Food
import com.example.foodapps.ui.theme.*

@Composable
fun FoodCard(
    food: Food,
    onAddToCart: (Food) -> Unit,
    onLikeClick: (Food) -> Unit,
    onBuyNow: (Food) -> Unit,
    onCardClick: (Food) -> Unit,  // Tambahan: klik seluruh card
    isLiked: Boolean
) {
    var count by remember { mutableIntStateOf(0) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .clickable { onCardClick(food) },  // Navigasi ke detail saat card diklik
        elevation = CardDefaults.cardElevation(6.dp),
        colors = CardDefaults.cardColors(containerColor = CardBackground)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Image(
                painter = painterResource(id = food.imageRes),
                contentDescription = food.nama,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Rp${food.harga}",
                color = PriceColor,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = food.nama,
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
                color = TextDark
            )

            Text(
                text = food.deskripsi,
                fontSize = 14.sp,
                color = TextGray,
                maxLines = 2
            )

            Spacer(modifier = Modifier.height(8.dp))

            ConstraintLayout(modifier = Modifier.fillMaxWidth()) {
                val (likeBtn, addBtn, buyBtn) = createRefs()

                createHorizontalChain(
                    likeBtn, addBtn, buyBtn,
                    chainStyle = ChainStyle.Spread
                )

                OutlinedButton(
                    onClick = { onLikeClick(food) },
                    modifier = Modifier.constrainAs(likeBtn) {
                        start.linkTo(parent.start)
                        end.linkTo(addBtn.start)
                    }
                ) {
                    Icon(
                        imageVector = if (isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = if (isLiked) "Disukai" else "Belum disukai"
                    )

                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Suka", fontSize = 10.sp)
                }

                Button(
                    onClick = {
                        count++
                        onAddToCart(food)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PastelBrown),
                    modifier = Modifier.constrainAs(addBtn) {
                        start.linkTo(likeBtn.end)
                        end.linkTo(buyBtn.start)
                    }
                ) {
                    Text("Tambah", color = Color.White, fontSize = 10.sp)
                }

                Button(
                    onClick = { onBuyNow(food) },
                    colors = ButtonDefaults.buttonColors(containerColor = LightBrown),
                    modifier = Modifier.constrainAs(buyBtn) {
                        start.linkTo(addBtn.end)
                        end.linkTo(parent.end)
                    }
                ) {
                    Text("Beli", color = Color.Black, fontSize = 10.sp)
                }
            }

            if (count > 0) {
                Spacer(modifier = Modifier.height(4.dp))
                Text("Jumlah ditambahkan: $count", fontSize = 12.sp, color = TextDark)
            }
        }
    }
}
