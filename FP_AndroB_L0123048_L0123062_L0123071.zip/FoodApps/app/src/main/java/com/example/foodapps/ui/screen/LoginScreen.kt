package com.example.foodapps.ui.screen

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.foodapps.datastore.UserPreference
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.ui.graphics.Color

@Composable
fun AuthScreen(navController: NavController) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0 = Login, 1 = Sign Up

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        TabRow(selectedTabIndex = selectedTab) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }) {
                Text("Login", modifier = Modifier.padding(16.dp))
            }
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }) {
                Text("Sign Up", modifier = Modifier.padding(16.dp))
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (selectedTab == 0) {
            LoginForm(navController)
        } else {
            SignUpForm(onSignUpSuccess = { selectedTab = 0 })
        }
    }
}

@Composable
fun SignUpForm(onSignUpSuccess: () -> Unit) {
    val context = LocalContext.current
    val userPref = remember { UserPreference(context) }

    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var showError by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Email") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = confirmPassword,
            onValueChange = { confirmPassword = it },
            label = { Text("Confirm Password") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = {
            if (password == confirmPassword && email.isNotBlank()) {
                CoroutineScope(Dispatchers.IO).launch {
                    userPref.saveUser(email, password)
                    withContext(Dispatchers.Main) {
                        onSignUpSuccess() // Balik ke tab Login
                    }
                }
            } else {
                showError = true
            }
        }) {
            Text("Sign Up")
        }

        if (showError) {
            Text("Password tidak cocok atau email kosong", color = Color.Red)
        }
    }
}

@Composable
fun LoginForm(navController: NavController) {
    val context = LocalContext.current
    val userPref = remember { UserPreference(context) }

    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var loginFailed by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Email") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = {
            CoroutineScope(Dispatchers.IO).launch {
                val valid = userPref.isValidLogin(email, password)
                if (valid) {
                    withContext(Dispatchers.Main) {
                        navController.navigate("home")
                    }
                } else {
                    withContext(Dispatchers.Main) {
                        loginFailed = true
                    }
                }
            }
        }) {
            Text("Login")
        }

        if (loginFailed) {
            Text("Login gagal. Coba lagi.", color = Color.Red)
        }
    }
}
