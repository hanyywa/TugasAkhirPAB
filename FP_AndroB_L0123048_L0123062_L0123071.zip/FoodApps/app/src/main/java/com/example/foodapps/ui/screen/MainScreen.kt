package com.example.foodapps.ui.screen

import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.foodapps.data.sampleFoods
import com.example.foodapps.viewmodel.ArticleViewModel
import com.example.foodapps.viewmodel.CartViewModel
import com.example.foodapps.viewmodel.FavoriteViewModel

@Composable
fun MainScreen() {
    val navController = rememberNavController()
    val articleViewModel: ArticleViewModel = viewModel()
    val cartViewModel: CartViewModel = viewModel()
    val favoriteViewModel: FavoriteViewModel = viewModel()

    NavHost(navController = navController, startDestination = "login") {

        composable("login") {
            AuthScreen(navController = navController)
        }

        composable("home") {
            FoodListScreen(
                navController = navController,
                cartViewModel = cartViewModel,
                favoriteViewModel = favoriteViewModel
            )
        }

        composable("foodList") {
            FoodListScreen(
                navController = navController,
                cartViewModel = cartViewModel,
                favoriteViewModel = favoriteViewModel
            )
        }

        composable("articleList") {
            ArticleListScreen(
                navController = navController,
                viewModel = articleViewModel
            )
        }

        composable("cart") {
            CartScreen(
                navController = navController,
                cartViewModel = cartViewModel
            )
        }

        composable("favorites") {
            FavoriteScreen(
                navController = navController,
                favoriteViewModel = favoriteViewModel
            )
        }

        composable(
            route = "detail/{foodId}",
            arguments = listOf(navArgument("foodId") { type = NavType.IntType })
        ) { backStackEntry ->
            val foodId = backStackEntry.arguments?.getInt("foodId") ?: 0
            FoodDetailScreen(
                foodId = foodId,
                navController = navController,
                cartViewModel = cartViewModel,
                favoriteViewModel = favoriteViewModel
            )
        }

        composable(
            route = "checkout/{foodId}",
            arguments = listOf(navArgument("foodId") { type = NavType.IntType })
        ) { backStackEntry ->
            val foodId = backStackEntry.arguments?.getInt("foodId") ?: 0
            val food = sampleFoods.find { it.id == foodId } ?: sampleFoods.first()
            CheckoutScreen(
                food = food,
                navController = navController,
                cartViewModel = cartViewModel
            )
        }

        composable(
            route = "payment_single/{foodId}",
            arguments = listOf(navArgument("foodId") { type = NavType.IntType })
        ) { backStackEntry ->
            val foodId = backStackEntry.arguments?.getInt("foodId") ?: 0
            val food = sampleFoods.find { it.id == foodId }
            if (food != null) {
                PaymentSingleScreen(
                    food = food,
                    navController = navController,
                    cartViewModel = cartViewModel
                )
            }
        }

        composable("payment") {
            PaymentScreen(
                navController = navController,
                cartViewModel = cartViewModel
            )
        }

        composable("history") {
            PurchaseHistoryScreen(
                navController = navController,
                cartViewModel = cartViewModel
            )
        }
    }
}
