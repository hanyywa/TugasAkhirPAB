package com.example.foodapps.ui.screen

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.foodapps.viewmodel.CartViewModel
import java.text.NumberFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CartScreen(
    navController: NavController,
    cartViewModel: CartViewModel
) {
    val cartItems = cartViewModel.cartItems.collectAsState().value
    val context = LocalContext.current

    // Hitung total harga
    val totalHarga = cartItems.sumOf { it.harga }
    val formattedTotal = NumberFormat.getNumberInstance(Locale("id", "ID")).format(totalHarga)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Keranjang") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Kembali")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            if (cartItems.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Keranjang kosong.")
                }
            } else {
                LazyColumn {
                    items(cartItems) { food ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            elevation = CardDefaults.cardElevation(4.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Gambar makanan
                                Image(
                                    painter = painterResource(id = food.imageRes),
                                    contentDescription = food.nama,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(72.dp)
                                        .aspectRatio(1f)
                                )

                                Spacer(modifier = Modifier.width(12.dp))

                                // Nama dan harga
                                Column(
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(
                                        text = food.nama,
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                    Text(
                                        text = "Rp${NumberFormat.getNumberInstance(Locale("id", "ID")).format(food.harga)}",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }

                                // Tombol hapus
                                IconButton(
                                    onClick = {
                                        cartViewModel.removeFromCart(food)
                                        Toast.makeText(context, "Item dihapus", Toast.LENGTH_SHORT).show()
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Hapus",
                                        tint = Color.Red
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Total Harga
                Text(
                    text = "Total: Rp$formattedTotal",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier
                        .align(Alignment.End)
                        .padding(vertical = 8.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = {
                        navController.navigate("payment")
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Beli Semua")
                }

            }
        }
    }
}
