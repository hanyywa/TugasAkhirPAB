package com.example.foodapps.ui.screen

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.foodapps.viewmodel.CartViewModel
import java.text.NumberFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PaymentScreen(
    navController: NavController,
    cartViewModel: CartViewModel
) {
    val context = LocalContext.current
    val cartItems = cartViewModel.cartItems.collectAsState().value
    val totalHarga = cartItems.sumOf { it.harga }
    val formattedTotal = NumberFormat.getNumberInstance(Locale("id", "ID")).format(totalHarga)

    var selectedMethod by remember { mutableStateOf("Transfer Bank") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Pembayaran") }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text("Total Pembayaran: Rp$formattedTotal", style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(16.dp))

                Text("Pilih Metode Pembayaran:")
                Spacer(modifier = Modifier.height(8.dp))

                val metodePembayaran = listOf("Transfer Bank", "E-Wallet", "COD")

                metodePembayaran.forEach { metode ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(
                            selected = selectedMethod == metode,
                            onClick = { selectedMethod = metode }
                        )
                        Text(text = metode)
                    }
                }

            }

            Button(
                onClick = {
                    val success = cartViewModel.checkout()
                    if (success) {
                        Toast.makeText(context, "Pembayaran berhasil!", Toast.LENGTH_SHORT).show()
                        navController.navigate("history") {
                            popUpTo("payment") { inclusive = true }
                        }
                    } else {
                        Toast.makeText(context, "Pembayaran gagal.", Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Bayar Sekarang")
            }
        }
    }
}
