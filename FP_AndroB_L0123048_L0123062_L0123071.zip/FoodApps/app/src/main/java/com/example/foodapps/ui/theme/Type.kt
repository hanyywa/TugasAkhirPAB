package com.example.foodapps.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.sp
import com.example.foodapps.R

val LatoFont = FontFamily(
    Font(R.font.lato_regular),
    Font(R.font.lato_bold)
)

val Typography = Typography(
    bodyLarge = TextStyle(
        fontFamily = LatoFont,
        fontSize = 16.sp
    ),
    titleLarge = TextStyle(
        fontFamily = LatoFont,
        fontSize = 20.sp
    ),
    labelLarge = TextStyle(
        fontFamily = LatoFont,
        fontSize = 14.sp
    )
)
