package com.example.foodapps.ui.screen

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.foodapps.components.FoodCard
import com.example.foodapps.data.sampleFoods
import com.example.foodapps.viewmodel.CartViewModel
import com.example.foodapps.viewmodel.FavoriteViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FoodListScreen(
    navController: NavController,
    cartViewModel: CartViewModel,
    favoriteViewModel: FavoriteViewModel
) {
    val favoriteItems by favoriteViewModel.favoriteItems.collectAsState()
    var searchQuery by remember { mutableStateOf("") }

    val filteredFoods = remember(searchQuery) {
        if (searchQuery.isBlank()) {
            sampleFoods
        } else {
            sampleFoods.filter {
                it.nama.contains(searchQuery, ignoreCase = true)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("List of Products") },
                actions = {
                    IconButton(onClick = { navController.navigate("history") }) {
                        Icon(Icons.AutoMirrored.Filled.List, contentDescription = "Riwayat")
                    }
                    IconButton(onClick = { navController.navigate("favorites") }) {
                        Icon(Icons.Default.Favorite, contentDescription = "Favorit")
                    }
                    IconButton(onClick = { navController.navigate("cart") }) {
                        Icon(Icons.Default.ShoppingCart, contentDescription = "Keranjang")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("Cari makanan...") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
            )

            LazyColumn {
                items(filteredFoods) { food ->
                    val isLiked = favoriteItems.contains(food)

                    FoodCard(
                        food = food,
                        isLiked = isLiked,
                        onCardClick = {
                            navController.navigate("detail/${food.id}")
                        },
                        onLikeClick = {
                            if (isLiked) {
                                favoriteViewModel.removeFromFavorites(food)
                            } else {
                                favoriteViewModel.addToFavorites(food)
                            }
                        },
                        onAddToCart = { cartViewModel.addToCart(food) },
                        onBuyNow = {
                            navController.navigate("checkout/${food.id}")
                        }
                    )
                }
            }
        }
    }
}
